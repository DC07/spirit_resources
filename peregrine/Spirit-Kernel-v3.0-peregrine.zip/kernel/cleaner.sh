#!/sbin/sh

# clean init.d scripts
INITD_DIR=/system/etc/init.d

# remove dalvik cache
#rm -rf /data/dalvik-cache
#rm -rf /cache/dalvik-cache
